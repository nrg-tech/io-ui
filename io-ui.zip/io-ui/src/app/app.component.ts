import { Component } from '@angular/core';

@Component({
  selector: 'io-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'io-ui';
}

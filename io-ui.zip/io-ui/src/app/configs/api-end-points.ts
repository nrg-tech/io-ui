export const apiEndPoints = {
    sampleTest: '/sample'
};

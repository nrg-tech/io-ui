import { environment } from 'src/environments/environment';
const baseAssetPath = environment.baseAssetPath;

export const assets = {
};
